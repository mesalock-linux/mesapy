name = "Mingshen Sun"

def print_name():
    print name
